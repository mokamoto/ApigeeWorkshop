var responsePayload = JSON.parse(context.getVariable("response.content"));
var responseFields =responsePayload.schema.fields;
var formattedResponse =[];

for (var i = 0; i < responsePayload.rows.length ; i++) {
    var responseRecord ={};
    for(var j = 0; j < responsePayload.rows[i].f.length ; j++) {
      responseRecord[responseFields[j].name] = responsePayload.rows[i].f[j].v;
    }
    formattedResponse.push(responseRecord);
}

context.setVariable("response.content", JSON.stringify(formattedResponse));