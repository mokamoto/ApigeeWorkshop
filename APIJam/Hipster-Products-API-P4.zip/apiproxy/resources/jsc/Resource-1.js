if(response.content){
  var data = JSON.parse(response.content);
  var tier = context.getVariable("verifyapikey.Verify-API-Key-1.apiproduct.Tier");

  if(!tier || tier !== "Gold")
  {
    for(var i=0;i < data.products.length; i++)
    {
      delete data.products[i].priceUsd;
      delete data.products[i].categories;  
    }
  }
  context.proxyResponse.headers['tier'] = tier; 
  context.proxyResponse.headers['content-type'] = 'application/json';
  context.proxyResponse.content = JSON.stringify(data, null, 2);
}
